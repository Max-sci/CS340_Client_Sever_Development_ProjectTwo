# Document Name "Animal_shelter.py"
# Maxwell J. Sciola
from pymongo import MongoClient, errors

class AnimalShelter(object):
    """ CRUD operations for Animals collection in MongoDB """

    def __init__(self):
        """
        Initialize MongoDB connection with authentication.
        Uses SNHU Codio host/port for MongoDB.
        """
        # Connection Variables
        USER = 'aacuser'   # Username
        PASS = 'MyCatWinston' # The best cat around
        HOST = 'localhost'  # Codio MongoDB host
        PORT = 27017      # Codio MongoDB port
        DB = 'aac'         # Database name
        COL = 'animals'    # Collection name

        try:
            # Connect with authentication source set to admin
            self.client = MongoClient(
                f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource=admin'
            )
            self.database = self.client[DB]
            self.collection = self.database[COL]

            # Test the connection
            self.client.admin.command('ping')
            print("Connected successfully to MongoDB")

        except errors.ServerSelectionTimeoutError as e:
            print(f"Could not connect to MongoDB: {e}")
            raise
        except errors.PyMongoError as e:
            print(f"MongoDB authentication or connection error: {e}")
            raise

    def create(self, data):
        """
        Inserts a new document into the animals collection.
        :param data: Dictionary with document fields
        :return: True if success, False otherwise
        """
        if data is None or not isinstance(data, dict) or len(data) == 0:
            print("Data parameter must be a non-empty dictionary")
            return False

        try:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        except errors.PyMongoError as e:
            print(f"An error occurred while inserting data: {e}")
            return False

    def read(self, query):
        """
        Queries documents from the animals collection.
        :param query: Dictionary with query conditions
        :return: List of matching documents
        """
        if not isinstance(query, dict):
            print("Query parameter must be a dictionary")
            return []

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except errors.PyMongoError as e:
            print(f"An error occurred while reading data: {e}")
            return []

    def update(self, query, new_values):
        """
        Updates documents in the animals collection.
        :param query: Dictionary with query conditions
        :param new_values: Dictionary with updated field values
        :return: Count of modified documents
        """
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            print("Both query and new_values must be dictionaries")
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except errors.PyMongoError as e:
            print(f"An error occurred while updating data: {e}")
            return 0

    def delete(self, query):
        """
        Deletes documents from the animals collection.
        :param query: Dictionary with query conditions
        :return: Count of deleted documents
        """
        if not isinstance(query, dict):
            print("Query parameter must be a dictionary")
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except errors.PyMongoError as e:
            print(f"An error occurred while deleting data: {e}")
            return 0